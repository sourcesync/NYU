#include <stdio.h>
#include <string.h>


#include "mex.h"




void
mexFunction( int nlhs, mxArray *plhs[],
             int nrhs,  const mxArray *prhs[] )
{


}
