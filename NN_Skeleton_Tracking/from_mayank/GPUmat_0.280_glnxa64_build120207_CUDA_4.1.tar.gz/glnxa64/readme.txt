Credits and License

Starting  from version  0.280, GPUmat  is distributed  as  open source
software  (please check  license.txt for  more  information). Versions
prior to 0.280  were developed and distributed by  the GP-you Group as
Freeware.

MATCUBLAS and MATCUFFT were  originally part of GPUmat.  Starting from
GPUmat version 0.2  these packages are available as  open source (GPL)
on Sourceforge (http://matcuda.sourceforge.net).

USER DEFINED  MODULES package  (folder GPUmat/modules) is  open source
(GPL)         and         downloadable        from         Sourceforge
(http://gpumatmodules.sourceforge.net).    This   package   has   been
developed by the  GP-you Group to allow users to  add new functions to
the GPUmat core.

Starting from GPUmat version 0.280, MATCUDA and USER DEFINED MODULES
packages are directly included in GPUmat.

