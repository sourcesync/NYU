% cufftExecR2C - Wrapper to CUFFT cufftExecR2C function
% 
% DESCRIPTION
% Wrapper to CUFFT cufftExecR2C function. Original function dec-
% laration:
% 
% cufftResult
% cufftExecR2C(cufftHandle plan,
%               cufftReal *idata,
%               cufftComplex *odata);
