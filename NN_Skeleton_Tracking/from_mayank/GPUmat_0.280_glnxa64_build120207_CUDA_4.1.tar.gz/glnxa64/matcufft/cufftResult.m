% cufftResult - Returns a structure with CUFFT result codes
% 
% DESCRIPTION
% Returns a structure with CUFFT result codes
