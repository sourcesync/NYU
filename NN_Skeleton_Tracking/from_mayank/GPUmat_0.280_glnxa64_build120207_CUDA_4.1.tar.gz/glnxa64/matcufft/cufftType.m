% cufftType - Returns a structure with CUFFT transform type codes
% 
% DESCRIPTION
% Returns a structure with CUFFT transform type codes.
