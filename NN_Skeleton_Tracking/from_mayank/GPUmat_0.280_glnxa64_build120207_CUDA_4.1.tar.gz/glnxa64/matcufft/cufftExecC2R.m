% cufftExecC2R - Wrapper to CUFFT cufftExecC2R function
% 
% DESCRIPTION
% Wrapper to CUFFT cufftExecC2R function. Original function dec-
% laration:
% 
% cufftResult
% cufftExecC2R(cufftHandle plan,
%               cufftComplex *idata,
%               cufftReal *odata);
