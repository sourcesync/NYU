% cuInit - Wrapper to CUDA driver function cuInit
% 
% MODULE NAME
% na
% 
% DESCRIPTION
% Wrapper to CUDA driver function cuInit.
