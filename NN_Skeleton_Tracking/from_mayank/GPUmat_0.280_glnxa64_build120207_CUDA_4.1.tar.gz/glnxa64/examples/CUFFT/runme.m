test_cufftCheckStatus
test_cufftExecC2C
test_cufftPlan1d
test_cufftDestroy
test_cufftPlan2d
simpleCUFFT       
