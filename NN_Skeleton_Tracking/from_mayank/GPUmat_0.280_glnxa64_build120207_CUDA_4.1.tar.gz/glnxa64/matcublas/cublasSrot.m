% cublasSrot - Wrapper to CUBLAS cublasSrot function
% 
% DESCRIPTION
% Wrapper to CUBLAS cublasSrot function.
% Original function declaration:
% 
% void
% cublasSrot (int n, float *x, int incx,
%               float *y, int incy, float sc,
%               float ss)
