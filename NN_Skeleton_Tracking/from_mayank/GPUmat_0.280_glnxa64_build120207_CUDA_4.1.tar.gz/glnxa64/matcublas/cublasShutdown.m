% cublasShutdown - Wrapper to CUBLAS cublasShutdown function
% 
% DESCRIPTION
% Wrapper to CUBLAS cublasShutdown function. Original function
% declaration:
% 
% cublasStatus
% cublasShutdown (void)
