IndexedReference
SliceAssign
GPUfill
memCpy
