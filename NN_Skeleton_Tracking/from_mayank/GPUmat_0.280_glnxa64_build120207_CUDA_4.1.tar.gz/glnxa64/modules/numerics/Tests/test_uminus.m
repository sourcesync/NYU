function test_uminus

config = defaultConfig();
config.optype =1;


op  = 'uminus';
checkfun(op,config);

end