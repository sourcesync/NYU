function y = rand_plusminusone( varargin)
%RAND_PLUSMINUSONE Summary of this function goes here
%   Detailed explanation goes here

y = 1 - 2*rand(cell2mat(varargin));

end

