% myexp - GPUmat compiled function
% SYNTAX
% myexp ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
