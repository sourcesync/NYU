function test_abs

config = defaultConfig();
config.optype =1;

op  = 'abs';
checkfun(op,config);

end
