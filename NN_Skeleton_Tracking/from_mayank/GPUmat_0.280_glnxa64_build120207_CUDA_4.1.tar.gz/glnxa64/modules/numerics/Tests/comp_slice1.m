% comp_slice1 - GPUmat compiled function
% SYNTAX
% comp_slice1 ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
% ARGS(1) - Matlab variable
