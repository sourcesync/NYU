function test_gt

config = defaultConfig();
config.optype =2;

op  = '>';
checkfun(op,config);

end