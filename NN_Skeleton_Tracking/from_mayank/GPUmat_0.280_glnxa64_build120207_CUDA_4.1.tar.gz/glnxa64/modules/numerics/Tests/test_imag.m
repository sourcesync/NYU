function test_imag

config = defaultConfig();
config.optype =1;

op  = 'imag';
checkfun(op,config);


end
