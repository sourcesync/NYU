function test_conj

config = defaultConfig();
config.optype =1;

op  = 'conj';
checkfun(op,config);

end
