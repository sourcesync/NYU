function y = rand_acosh( varargin)

y = 1+pi*rand(cell2mat(varargin));

end

