% comp_GPUzeros - GPUmat compiled function
% SYNTAX
% comp_GPUzeros ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
