% comp_permute - GPUmat compiled function
% SYNTAX
% comp_permute ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
% ARGS(1) - Matlab variable
