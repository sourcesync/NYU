% comp_GPUeye - GPUmat compiled function
% SYNTAX
% comp_GPUeye ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
