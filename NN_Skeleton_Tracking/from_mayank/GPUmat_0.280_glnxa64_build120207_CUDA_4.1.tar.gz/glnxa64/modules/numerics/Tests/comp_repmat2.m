% comp_repmat2 - GPUmat compiled function
% SYNTAX
% comp_repmat2 ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
% ARGS(1) - Matlab variable
% ARGS(2) - Matlab variable
