function test_GPUreal

config = defaultConfig();
config.optype =3;

op  = 'real';
checkfun(op,config);


end
