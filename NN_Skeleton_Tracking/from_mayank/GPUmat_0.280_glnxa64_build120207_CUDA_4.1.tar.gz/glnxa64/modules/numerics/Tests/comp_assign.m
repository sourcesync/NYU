% comp_assign - GPUmat compiled function
% SYNTAX
% comp_assign ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
% ARGS(1) - GPU variable (GPUdouble, GPUsingle, ...)
