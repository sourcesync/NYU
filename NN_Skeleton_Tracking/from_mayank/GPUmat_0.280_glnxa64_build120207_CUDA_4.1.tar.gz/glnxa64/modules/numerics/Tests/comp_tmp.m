% comp_tmp - GPUmat compiled function
% SYNTAX
% comp_tmp ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
