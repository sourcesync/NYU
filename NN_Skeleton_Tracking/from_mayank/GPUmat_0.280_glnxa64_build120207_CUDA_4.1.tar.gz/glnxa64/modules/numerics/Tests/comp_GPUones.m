% comp_GPUones - GPUmat compiled function
% SYNTAX
% comp_GPUones ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
