function test_GPUimag

config = defaultConfig();
config.optype =3;

op  = 'imag';
checkfun(op,config);


end
