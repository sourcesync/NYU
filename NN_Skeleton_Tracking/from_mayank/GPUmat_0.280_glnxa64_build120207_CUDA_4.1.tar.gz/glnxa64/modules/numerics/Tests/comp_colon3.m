% comp_colon3 - GPUmat compiled function
% SYNTAX
% comp_colon3 ( ARGS ), where ARGS are:
% ARGS(0) - Matlab variable
% ARGS(1) - Matlab variable
% ARGS(2) - Matlab variable
% ARGS(3) - GPU variable (GPUdouble, GPUsingle, ...)
