function test_GPUtimes

config = defaultConfig();
config.optype =4;

op  = 'times';
checkfun(op,config);

end