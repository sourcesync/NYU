% comp_ones2 - GPUmat compiled function
% SYNTAX
% comp_ones2 ( ARGS ), where ARGS are:
% ARGS(0) - Matlab variable
% ARGS(1) - Matlab variable
% ARGS(2) - GPU variable (GPUdouble, GPUsingle, ...)
