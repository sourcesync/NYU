function test_times

config = defaultConfig();
config.optype =2;

op  = '.*';
checkfun(op,config);

end