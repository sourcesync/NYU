function test_exp

config = defaultConfig();
config.optype =1;

op  = 'exp';
checkfun(op,config);

end