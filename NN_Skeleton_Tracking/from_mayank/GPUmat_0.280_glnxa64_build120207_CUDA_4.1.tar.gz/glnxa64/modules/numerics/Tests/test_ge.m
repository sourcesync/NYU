function test_ge

config = defaultConfig();
config.optype =2;

op  = '>=';
checkfun(op,config);

end