function test_real

config = defaultConfig();
config.optype =1;

op  = 'real';
checkfun(op,config);


end
