% comp_GPUfill - GPUmat compiled function
% SYNTAX
% comp_GPUfill ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
% ARGS(1) - Matlab variable
% ARGS(2) - Matlab variable
% ARGS(3) - Matlab variable
% ARGS(4) - Matlab variable
% ARGS(5) - Matlab variable
% ARGS(6) - Matlab variable
