% comp_memCpyDtoD - GPUmat compiled function
% SYNTAX
% comp_memCpyDtoD ( ARGS ), where ARGS are:
% ARGS(0) - GPU variable (GPUdouble, GPUsingle, ...)
% ARGS(1) - GPU variable (GPUdouble, GPUsingle, ...)
% ARGS(2) - Matlab variable
% ARGS(3) - Matlab variable
