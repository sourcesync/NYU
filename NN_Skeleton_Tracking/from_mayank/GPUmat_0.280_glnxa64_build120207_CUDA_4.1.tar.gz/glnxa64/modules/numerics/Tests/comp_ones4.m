% comp_ones4 - GPUmat compiled function
% SYNTAX
% comp_ones4 ( ARGS ), where ARGS are:
% ARGS(0) - Matlab variable
% ARGS(1) - Matlab variable
% ARGS(2) - Matlab variable
% ARGS(3) - Matlab variable
% ARGS(4) - GPU variable (GPUdouble, GPUsingle, ...)
