% comp_ones5 - GPUmat compiled function
% SYNTAX
% comp_ones5 ( ARGS ), where ARGS are:
% ARGS(0) - Matlab variable
% ARGS(1) - Matlab variable
% ARGS(2) - Matlab variable
% ARGS(3) - Matlab variable
% ARGS(4) - Matlab variable
% ARGS(5) - GPU variable (GPUdouble, GPUsingle, ...)
