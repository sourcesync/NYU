% comp_ones1 - GPUmat compiled function
% SYNTAX
% comp_ones1 ( ARGS ), where ARGS are:
% ARGS(0) - Matlab variable
% ARGS(1) - GPU variable (GPUdouble, GPUsingle, ...)
