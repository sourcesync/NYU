%CUCOPYINTO Zero-padding
%
%   CUCOPYINTO(A,B,p) copies every image (columns of A) into a larger
%   image (columns of B) where there is a padding of size p around each
%   original image
%   INPUTS:
%     A : (imgSize * imgSize) x numCases SQUARE images
%     B : (imgSize+2*p)*(imgSize+2*p) x numCases SQUARE result images
%     p : integer padding size 
