void _gtm(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[], bool reverse);
