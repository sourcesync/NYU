%CURANDN Normally distributed random number genration on GPU.
%
%   A = CURANDN(m,n,GPUsingle) produces a m by n matrix A 
%   A = CURANDN(m,n,GPUsingle) produces a m by n by p array A
%   A = CURANDN([m n],GPUsingle) is the same as
%     A = CURANDN(m,n,GPUsingle)
%