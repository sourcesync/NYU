function runme
%% run test

testcuConv %every image with every filter
testcuConv2 %filterbank per image
testcuConv3 %sum over convolutions - each image has an associated filter
%end